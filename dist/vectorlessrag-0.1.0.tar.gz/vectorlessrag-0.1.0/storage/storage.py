import os
import json
import hashlib

class Storage:

    def _generate_doc_id(self, file_path: str) -> str:
        filename = os.path.splitext(os.path.basename(file_path))[0]
        file_hash = hashlib.md5(open(file_path, "rb").read()).hexdigest()[:6]
        return f"{filename}_{file_hash}"

    def add_to_storage(self, tree_docs: dict,topic_name:str,file_path:str,doc_pages):

        """
    Saves a document's tree index to disk under the given topic.
    
    Creates the following structure:
        storage/
            registry.json          ← tracks which docs belong to which topic
            {topic_name}/          ← one folder per topic
                {doc_id}.json      ← one JSON file per document (intended)
    
    Parameters:
        tree_docs   : the tree dict returned by the indexer (the LLM-generated structure)
        topic_name  : the category this document belongs to e.g. "annual_reports"
    """
        doc_id = self._generate_doc_id(file_path)
        #Step 1: Make sure the top-level storage/ folder exists
        # exist_ok=True means: don't crash if it already exists, just continue
        os.makedirs("storage", exist_ok=True)
        # Step 2: Define where registry.json should live
        registry_path = os.path.join("storage","registry.json")

    # Step 3: If registry.json doesn't exist yet (first ever document),
    # create it with an empty dict {} so we can add to it later
        
             
        if not os.path.exists(registry_path):

            with open(registry_path, "w") as f:
                json.dump({}, f)
    # Step 4: Load the existing registry.json into a Python dict
        with open(registry_path, "r") as f:
            registry = json.load(f)
            if topic_name in registry:
                registry[topic_name].append(doc_id)
            else:
                registry[topic_name] = [doc_id]
    # Step 5: Write the updated registry back to disk
        with open(registry_path, "w") as f:
            json.dump(registry, f, indent=2)    
        
    # Step 4: Build the path to the topic folder e.g. "storage/annual_reports"

        full_path = os.path.join("storage",f"{topic_name}")
    # Step 5: Create the topic folder if it doesn't exist
        os.makedirs(full_path, exist_ok=True)

        pages_file = os.path.join(full_path,f"{doc_id}_pages.json")

        with open(pages_file, "w") as pf:
            json.dump(doc_pages, pf, indent=2)

        doc_file = os.path.join(full_path, f"{doc_id}.json")  # "storage/annual_reports/apple_2024_report_a3f9c2.json"
       
        with open(doc_file, "w") as f:
                json.dump(tree_docs, f, indent=2)
        return doc_id



    def get_topics(self):
        registry_path = os.path.join("storage", "registry.json")
        if not os.path.exists(registry_path):
            return []
        with open(os.path.join("storage","registry.json"), "r") as f:
            registry = json.load(f)
            return list(registry.keys())
    
    def get_topic_index(self, topic_name: str):
        registry_path = os.path.join("storage", "registry.json")
        if not os.path.exists(registry_path):
            return {}
        with open(os.path.join("storage","registry.json"), "r") as f:
            registry = json.load(f)
            doc_ids = registry.get(topic_name, [])
            topic_indices = {}
            for doc_id in doc_ids:
                doc_path = os.path.join("storage", topic_name, f"{doc_id}.json")
                with open(doc_path, "r") as df:
                    tree_doc = json.load(df)
                    topic_indices[doc_id] = tree_doc
            return topic_indices

    def load_doc_pages(self, topic_name:str, doc_id:str):
        pages_file = os.path.join("storage",topic_name,f"{doc_id}_pages.json")
        if not os.path.exists(pages_file):
            return []
        with open(pages_file, "r") as pf:
            pages = json.load(pf)
            return pages